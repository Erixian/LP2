﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Valor inválido");
                txtLadoA.Focus();
            }
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Valor inválido");
                txtLadoA.Focus();
            }
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Valor invalido");
                txtLadoA.Focus();
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (ladoA != 0 && ladoB != 0 && ladoC != 0)
            {
                double deltaCB = Math.Abs(ladoC - ladoB);
                double deltaCA = Math.Abs(ladoC - ladoA);
                double deltaAB = Math.Abs(ladoA - ladoB);
                double sumBC = ladoB + ladoC;
                double sumAC = ladoA + ladoC;
                double sumAB = ladoA + ladoB;

                if ((ladoA > deltaCB && ladoA < sumBC) && (ladoB > deltaCA && ladoB < sumAC) && (ladoC > deltaAB && ladoC < sumAB))
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                    {
                        MessageBox.Show("Triangulo Equilatero");
                    }
                    else if (ladoA == ladoB || ladoB == ladoC || ladoC == ladoA)
                    {
                        MessageBox.Show("Triangulo isóceles");
                    }
                    else
                        MessageBox.Show("Triangulo escaleno");

                }
                else
                    MessageBox.Show("Não forma triangulo");

            }
            else
            {
                MessageBox.Show("Nenhum lado pode ter valor 0");
                if (ladoA == 0)
                    txtLadoA.Focus();
                else if (ladoB == 0)
                    txtLadoB.Focus();
                else
                    txtLadoC.Focus();
            }


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = String.Empty;
            txtLadoB.Text = String.Empty;
            txtLadoC.Text = String.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }


    }
}
