﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxAltura.Text, out altura) || (altura == 0))
            {
                MessageBox.Show("Valor de altura inválido");
                mskbxAltura.Focus();
            }
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso) || (peso == 0))
            {
                MessageBox.Show("Valor de peso inválido");
                mskbxPeso.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
            imc = Math.Round(imc, 1);

            txtImc.Text = imc.ToString();

            if (imc < 18.5)
            {
                MessageBox.Show("MAGREZA");
            }
            else if (imc < 24.9)
            {
                MessageBox.Show("NORMAL");
            }
            else if (imc < 29.9)
            {
                MessageBox.Show("SOBREPESO");
            }
            else if (imc < 39.9)
            {
                MessageBox.Show("OBESIDADE");
            }
            else
            {
                MessageBox.Show("OBESIDADE GRAVE!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtImc.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja mesmo sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
